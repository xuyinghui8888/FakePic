Based on coding format according to Google c++ style.
Except for functions with small letter to begin with. 
```
void getFormat();
```